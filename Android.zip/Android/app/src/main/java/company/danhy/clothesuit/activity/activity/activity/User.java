package company.danhy.clothesuit.activity.activity.activity;

public class User {

    String email, username, password;

    public User( String username,String email ,  String password) {
        this.email = email;
        this.username = username;
        this.password = password;
    }

}
