package company.danhy.clothesuit.activity.activity.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import company.danhy.clothesuit.R;

public class ThongTinActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thong_tin);
    }
}
