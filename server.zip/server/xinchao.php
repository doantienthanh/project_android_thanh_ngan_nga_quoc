<?php 
    echo "Xin chào việt Nam .. .
    Chào cái củ cải !!!!";
?>
